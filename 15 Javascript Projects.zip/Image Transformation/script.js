let icon= document.querySelector('.moon_icon');

icon.onclick = function()
{
    document.body.classList.toggle("dark_theme");
    if(document.body.classList.contains("dark_theme")){
    icon.src = "dark theme icon/sun.png"
    }else{
        icon.src = "dark theme icon/moon.png"   
    }
}